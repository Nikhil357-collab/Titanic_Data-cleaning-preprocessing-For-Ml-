from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

RAW_DATA_PATH = BASE_DIR / "data" / "raw" / "dataset.csv"
PROCESSED_DATA_PATH = BASE_DIR / "outputs" / "processed" / "cleaned_dataset.csv"
FIGURES_PATH = BASE_DIR / "outputs" / "figures"

TARGET_COLUMN = "target"  # Change this to your dataset target column
TEST_SIZE = 0.20
RANDOM_STATE = 42
IQR_MULTIPLIER = 1.5