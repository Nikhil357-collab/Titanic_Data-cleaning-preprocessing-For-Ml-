from sklearn.preprocessing import StandardScaler
from data_loader import df
import pandas as pd

scaler = StandardScaler()
df[["Age", "Fare"]] = scaler.fit_transform(df[["Age", "Fare"]])

#######################
df["FamilySize"] = (
    df["SibSp"] +
    df["Parch"] +
    1
)
###########################
df["IsAlone"] = (
    df["FamilySize"] == 1
).astype(int)
#######ENCODING##############
df = pd.get_dummies(
    df,
    columns=["Sex", "Embarked"],
    drop_first=True,
    dtype=int
)
df.head()
"""encoding complete"""
################

