import pandas as pd
import numpy as np

import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.preprocessing import StandardScaler
from data_loader import df
plt.figure(figsize=(10, 5))

sns.heatmap(
    df.isnull(),
    cbar=False
)

plt.title("Missing Values")

plt.tight_layout()

plt.savefig(
    "outputs/missing_values.png"
)

plt.show()
df.describe()
df.describe(include="object")

print( "Duplicate rows:",
    df.duplicated().sum()
)

df = df.drop_duplicates()

df["Age"] = df["Age"].fillna(
    df["Age"].median()
)
df["Embarked"] = df["Embarked"].fillna(
    df["Embarked"].mode()[0]
)

df["Fare"] = df["Fare"].fillna(
    df["Fare"].median()
)

df["CabinKnown"] = df["Cabin"].notna().astype(int)
##############
df = df.drop(columns=["Cabin"])

