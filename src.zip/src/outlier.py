from data_loader import df
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler
plt.figure(figsize=(8, 5))

sns.boxplot(
    x=df["Age"]
)

plt.title("Age Outliers")

plt.show()
######################################
plt.figure(figsize=(8, 5))

sns.boxplot(
    x=df["Fare"]
)

plt.title("Fare Outliers")

plt.show()
####Remove outlier IQR method
Q1 = df["Fare"].quantile(0.25)

Q3 = df["Fare"].quantile(0.75)

IQR = Q3 - Q1

lower_bound = Q1 - 1.5 * IQR

upper_bound = Q3 + 1.5 * IQR

df = df[
    (df["Fare"] >= lower_bound) &
    (df["Fare"] <= upper_bound)
]
##STANDARDIZATION#############
scaler = StandardScaler()

numerical_columns = [
    "Age",
    "Fare",
    "SibSp",
    "Parch",
    "FamilySize"
]

df[numerical_columns] = scaler.fit_transform(
    df[numerical_columns]
)
df[numerical_columns].describe()

df.to_csv(
    "outputs/cleaned/titanic_cleaned.csv",
    index=False
)

print(
    "Cleaned dataset saved successfully."
)