# Data Cleaning and Preprocessing Report

**Created:** 28-August-2026 01:11 AM

## Dataset Overview

| Metric | Value |
|---|---:|
| Raw rows | 891 |
| Raw columns | 12 |
| Processed rows | 658 |
| Processed columns | 990 |
| Target column | `survived` |
| Missing values in raw data | 866 |
| Duplicate rows removed | 0 |
| Outlier rows removed | 233 |

## Numerical Features

`passengerid`, `pclass`, `age`, `sibsp`, `parch`, `fare`

## Categorical Features

`name`, `sex`, `ticket`, `cabin`, `embarked`

## Missing Values Before Processing

- `Age`: 177
- `Cabin`: 687
- `Embarked`: 2

## Actions Performed

- Standardized column names.
- Converted text placeholders into missing values.
- Removed duplicate rows.
- Applied median imputation to numerical columns.
- Applied most-frequent imputation to categorical columns.
- One-hot encoded categorical features.
- Standardized numerical features.
- Visualized outliers using boxplots.
- Removed IQR outliers from training data only.
